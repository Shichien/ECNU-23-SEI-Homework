//
// Created by Deralive (10235101526) on 2024/05/16.
// Academic Contact: 10235101526 @ stu.ecnu.edu.cn
// Business Contact: Deralive @ 163.com / 2642136260 @ qq.com
//

template <class Node_entry>
struct Node
{
    // data members
    Node_entry entry;       // The data of the Node
    Node<Node_entry> *next; // The link to the next Node
    Node<Node_entry> *back; // The link to the previous Node
    // constructors
    Node();
    Node(Node_entry item, Node<Node_entry> *link_back = NULL, Node<Node_entry> *link_next = NULL);
    // Initialize the Node with item and links
};
