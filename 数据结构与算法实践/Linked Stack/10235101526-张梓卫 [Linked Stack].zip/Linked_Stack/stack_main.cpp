//
// Created by Deralive (10235101526) on 2024/4/11.
// Academic Contact: 10235101526 @ stu.ecnu.edu.cn
// Business Contact: Deralive @ 163.com / 2642136260 @ qq.com
//

#include "Stack.cpp"
#include <iostream>

using namespace std;

int main() {

    /*
    * Pre : None.
    * Post: Output the tip information
    */
    Stack<double> numbers;
    int n;
    double item;
    cout << "please input an integer n followed by n decimal numbers." << endl;
    cin >> n;

    /*
    * Pre : None.
    * Post: Read the input from the user.
    */
    for (int i = 0; i < n; i++) {
        cin >> item;
        numbers.push(item);
    }

    /*
    * Pre : The user already input the numbers.
    * Post: Output the numbers from the stack.
    */
    cout << endl << "Result: " << endl;
    while (!numbers.empty()) {
        numbers.top(item);
        cout << item << " ";
        numbers.pop();
    }
    cout << endl;
    
    system("pause");
}