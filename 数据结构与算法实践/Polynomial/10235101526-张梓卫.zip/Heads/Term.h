//
// Created by Deralive (10235101526) on 2024/04/25.
// Academic Contact: 10235101526 @ stu.ecnu.edu.cn
// Business Contact: Deralive @ 163.com / 2642136260 @ qq.com
//

class Term {
public:
    Term(int exponent = 0, double scalar = 0);
    int degree; // Degree of the term, the exponent of x
    double coefficient; // Coefficient of the term, the scalar of x
};