//
// Created by Deralive (10235101526) on 2024/05/16.
// Academic Contact: 10235101526 @ stu.ecnu.edu.cn
// Business Contact: Deralive @ 163.com / 2642136260 @ qq.com
//

#include "ListsNode.h"

/*
Pre: None.
Post: The Node is initialized with next pointing to NULL.
*/
template <class Node_entry>
Node<Node_entry>::Node()
{
    next = NULL; // Set the next to NULL
}

/*
Pre: None.
Post: The Node is initialized with entry set to item and next set to add_on.
*/
template <class Node_entry>
Node<Node_entry>::Node(Node_entry item, Node<Node_entry> *link_back, Node<Node_entry> *link_next)
{
    entry = item;     // Set the entry to item
    back = link_back; // Set the back to link_back
    next = link_next; // Set the next to link_next
}